# Philosophy AI — Gemini API + Android APK/PWA

यह प्रोजेक्ट आपके `index.html` UI को बनाए रखते हुए canned/demo replies की जगह server-side Google Gemini API call जोड़ता है।

## सुरक्षा — बहुत ज़रूरी
- Gemini API key को `public/index.html`, JavaScript, GitHub या APK में कभी न डालें।
- Key केवल hosting provider के Environment Variables में `GEMINI_API_KEY` नाम से रखें।
- अगर key कभी सार्वजनिक हो गई हो तो उसे Google AI Studio/Cloud में revoke करके नई key बनाएं।
- Gemini API के इस्तेमाल पर quota/charges लागू हो सकते हैं; अपने Google AI Studio project की billing/quota शर्तें जाँचें।
- Chat endpoint सार्वजनिक होने पर अन्य लोग भी requests भेज सकते हैं। शुरुआत में private testing करें और production में authentication/rate limits जोड़ें।

## Files
- `public/index.html` — UI + real chat API integration
- `public/manifest.json`, `public/sw.js`, `public/icon.svg` — installable PWA assets
- `server.js` — Express server; Gemini key server पर रखता है
- `render.yaml` — Render deploy configuration

## Android फोन से deploy करने के चरण

### 1. Gemini API key बनाएं
1. Chrome में Google AI Studio खोलें: https://aistudio.google.com/
2. अपने Google account से sign in करें और API key बनाएं।
3. Key को Notes, chat, GitHub या HTML में paste न करें। उसे केवल अगले hosting step में Environment Variable के रूप में जोड़ें।

### 2. GitHub पर project upload करें
1. GitHub पर नया repository बनाएं, उदाहरण `philosophy-ai-gemini`।
2. ZIP extract करें। Repository में `public` folder, `server.js`, `package.json`, `render.yaml`, `README.md` सीधे root में होने चाहिए।
3. GitHub mobile website पर **Add file → Upload files** से files upload करके commit करें। `node_modules` upload न करें।

### 3. Render पर backend + website deploy करें
1. https://render.com/ खोलें और GitHub से sign in/connect करें।
2. **New → Web Service** चुनें और अपना repository connect करें।
3. Build command: `npm install`
4. Start command: `npm start`
5. Environment में यह variable जोड़ें:
   - Key: `GEMINI_API_KEY`
   - Value: आपकी Gemini API key
   वैकल्पिक: `GEMINI_MODEL` = `gemini-2.5-flash`
6. Deploy पूरा होने पर Render की `https://....onrender.com` URL खोलें।
7. Health check के लिए `https://....onrender.com/api/health` खोलें। `keyConfigured: true` दिखना चाहिए। यह endpoint key को नहीं दिखाता।

> Render का free service idle रहने पर sleep हो सकता है; पहली request धीमी हो सकती है। API quota और model availability Google account/project पर निर्भर हैं।

### 4. असली AI जाँचें
Website खोलें, chat में पूछें: `चेतना क्या है? इसे सरल हिंदी में समझाओ।`
यदि error आए:
- `/api/health` पर `keyConfigured: true` जाँचें।
- Render Dashboard → Logs में error देखें।
- Google AI Studio में key/project/model और quota जाँचें।
- API key को browser console या HTML में कभी न रखें।

### 5. Android APK बनाएं (फोन से)
1. पहले website को HTTPS Render URL पर live करें।
2. Chrome में https://www.pwabuilder.com/ खोलें।
3. अपनी Render website URL डालें और site analysis चलाएं।
4. `Package for stores` → Android → `Generate Package` चुनें।
5. Personal phone पर test करने के लिए उपलब्ध Android package/ APK विकल्प चुनें; package settings में app name `Philosophy AI` रखें।
6. Generated package download करें और ZIP खोलें। अगर APK शामिल है, उसे install करें। Android Settings में केवल उसी डाउनलोड के लिए “Install unknown apps” अनुमति दें, install के बाद अनुमति बंद कर सकते हैं।
7. PWABuilder का Android package एक web-based Trusted Web Activity हो सकता है, full native offline app नहीं। Gemini chat के लिए internet चाहिए। यदि package में केवल AAB मिले, वह सीधे फोन पर install नहीं होता; APK/test package option चुनें।
8. Play Store पर publish करना अलग प्रक्रिया है और Google Play developer account/verification की जरूरत हो सकती है।

## Local testing (optional)
Node.js environment में:
```bash
npm install
# macOS/Linux:
GEMINI_API_KEY="YOUR_KEY_HERE" npm start
```
Windows PowerShell में:
```powershell
$env:GEMINI_API_KEY="YOUR_KEY_HERE"
npm start
```
फिर `http://localhost:10000` खोलें।

## Notes
- PWA shell कुछ assets cache करता है; AI responses offline काम नहीं करेंगे।
- `GEMINI_API_KEY` कभी `.env` file को GitHub पर upload न करें।
- इस starter में basic input size validation है, लेकिन public deployment के लिए authentication, rate limiting, usage limits और privacy notice जोड़ना बेहतर है।
