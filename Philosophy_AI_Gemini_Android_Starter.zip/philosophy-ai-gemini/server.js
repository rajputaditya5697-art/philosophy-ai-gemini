import express from "express";
import path from "node:path";
import { fileURLToPath } from "node:url";

const app = express();
const PORT = process.env.PORT || 10000;
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PUBLIC_DIR = path.join(__dirname, "public");
const MODEL = process.env.GEMINI_MODEL || "gemini-2.5-flash";

app.disable("x-powered-by");
app.use(express.json({ limit: "32kb" }));
app.use(express.static(PUBLIC_DIR, { extensions: ["html"] }));

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, service: "Philosophy AI", model: MODEL, keyConfigured: Boolean(process.env.GEMINI_API_KEY) });
});

app.post("/api/chat", async (req, res) => {
  try {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      return res.status(503).json({ error: "Server पर GEMINI_API_KEY सेट नहीं है।" });
    }

    const message = typeof req.body?.message === "string" ? req.body.message.trim() : "";
    if (!message) return res.status(400).json({ error: "अपना प्रश्न लिखें।" });
    if (message.length > 4000) return res.status(413).json({ error: "प्रश्न 4000 अक्षरों से छोटा रखें।" });

    const level = ["beginner", "intermediate", "advanced"].includes(req.body?.level)
      ? req.body.level : "beginner";
    const persona = typeof req.body?.persona === "string"
      ? req.body.persona.slice(0, 80) : "Philosophy Guide";

    const history = Array.isArray(req.body?.history) ? req.body.history.slice(-12) : [];
    const contents = [];
    for (const item of history) {
      if (!item || !["user", "model"].includes(item.role) || typeof item.text !== "string") continue;
      const text = item.text.trim().slice(0, 4000);
      if (text) contents.push({ role: item.role, parts: [{ text }] });
    }
    contents.push({ role: "user", parts: [{ text: message }] });

    const levelGuide = {
      beginner: "सरल हिंदी, छोटे वाक्य और रोजमर्रा के उदाहरण दें।",
      intermediate: "तर्कपूर्ण विश्लेषण दें, भारतीय और पाश्चात्य दर्शन में तुलना करें जहाँ उचित हो।",
      advanced: "गहरा दार्शनिक विश्लेषण दें; संस्कृत शब्दों का अर्थ और संदर्भ सावधानी से समझाएँ।"
    }[level];

    const upstream = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(MODEL)}:generateContent`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-goog-api-key": apiKey
        },
        body: JSON.stringify({
          system_instruction: {
            parts: [{
              text: `आप Philosophy AI हैं—दर्शन, चेतना, नैतिकता, भारतीय दर्शन और जीवन के प्रश्नों पर मदद करने वाले सहायक। उत्तर मुख्यतः स्वाभाविक हिंदी में दें; उपयोगकर्ता Hinglish लिखे तो सहज Hinglish भी ठीक है। चुना गया मार्गदर्शक/persona: ${persona}. अध्ययन स्तर: ${level}. ${levelGuide} तथ्य, दार्शनिक मत और व्यक्तिगत व्याख्या में अंतर रखें। किसी शास्त्र का श्लोक या उद्धरण निश्चित न हो तो उसे गढ़कर प्रमाणित उद्धरण न बताएं। सम्मानजनक, गैर-उपदेशात्मक और स्पष्ट रहें।`
            }]
          },
          contents,
          generationConfig: { temperature: 0.7, maxOutputTokens: 900 }
        })
      }
    );

    const payload = await upstream.json().catch(() => ({}));
    if (!upstream.ok) {
      const detail = payload?.error?.message || `Gemini API ने ${upstream.status} लौटाया।`;
      const status = upstream.status === 429 ? 429 : 502;
      return res.status(status).json({ error: detail });
    }

    const reply = (payload?.candidates?.[0]?.content?.parts || [])
      .map(part => part.text || "")
      .join("\n")
      .trim();

    if (!reply) return res.status(502).json({ error: "Gemini से उत्तर नहीं मिला। मॉडल/क्वोटा सेटिंग जाँचें।" });
    res.json({ reply, model: MODEL });
  } catch (error) {
    console.error("Chat request failed:", error?.message || error);
    res.status(500).json({ error: "सर्वर में समस्या हुई। थोड़ी देर बाद कोशिश करें।" });
  }
});

app.get("*", (req, res, next) => {
  if (req.path.startsWith("/api/")) return next();
  res.sendFile(path.join(PUBLIC_DIR, "index.html"));
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`Philosophy AI listening on port ${PORT}`);
});
