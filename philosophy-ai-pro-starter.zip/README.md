# Philosophy AI — Pro Starter

Features included:
- Login and Register with email/password
- Logout and token-based session
- Password hashing on the server
- Responsive dark navy + gold interface
- Philosophy Q&A using Gemini API
- Topic explorer and philosopher guide
- Local chat history and saved library
- Daily quote card
- Premium plans screen (UI only; payment is NOT enabled)
- Profile, language preference and theme preference

## Setup
1. Install Node.js on a computer or deploy on a Node.js hosting service.
2. Copy `.env.example` to `.env`.
3. Set `GEMINI_API_KEY` and a long random `JWT_SECRET`.
4. Run `npm install`, then `npm start`.
5. Open `http://localhost:3000`.

## Important limitations
- Do not upload `.env` or secrets to GitHub.
- The included JSON-file user store is a beginner demo, not a production database. Use a managed database, rate limits, HTTPS, backups, secure cookie/session strategy, privacy policy, terms, and account deletion flow before public release.
- Premium pricing is a UI placeholder only. No payment is taken and no account can be marked premium by purchasing. To launch paid premium, integrate a provider such as Razorpay with server-side signature/webhook verification and subscription state in the database.
- Google/Apple sign-in and password reset are not configured.
- Chat history/library are stored locally in the current browser/device; they do not sync across devices.
- The system prompt encourages careful philosophical answers but cannot guarantee perfect correctness. Verify important claims and quotations.
- If `gemini-2.5-flash` is unavailable for your API project, select a currently supported text model.
